package org.service;

import java.sql.*;

import org.util.SQLUtil;

public class classTable {
	private static final String URL = "jdbc:sqlserver://localhost:1433;DatabaseName=CollegeDB";
	private static final String USERNAME = "user";
	private static final String PWD = "123";
	public static Connection conn = null;
	public static PreparedStatement pstmt = null;
	public static ResultSet rs = null;
	
	public static String getClassTable(String dept_name, String class_num) {
		
		 try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(URL, USERNAME, PWD);
			String sql = "select * from classTable(?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dept_name);
			pstmt.setString(2, class_num);
			
			rs = pstmt.executeQuery();
			return SQLUtil.getHtmlTable(rs);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return "异常";
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "异常";
		}finally {
			try {
				if(rs != null)	rs.close();
				if(pstmt != null)	pstmt.close();
				if(conn != null)	conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
				return "异常";
			}catch (Exception e) {
				e.printStackTrace();
				return "异常";
			}
			
			
		}
	}

}
