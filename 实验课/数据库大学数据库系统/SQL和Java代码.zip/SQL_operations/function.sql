create function classTable(@dept_name varchar(20), @class_num char(10))
returns table
as
	return (select sc.dept_name ϵ��, sc.class_num �༶��, sc.course_id �γ̺�,course.title �γ���, 
		sec.building + sec.room_number ����, sec.sec_day + start_time ����
	from 
		section sec 
		join sec_class sc 
			on(sec.course_id = sc.course_id and sec.sec_id = sc.sec_id 
				and sec.semester = sc.semester and sec.sec_year = sc.sec_year) 
		join course 
			on(sc.course_id = course.course_id)
	where sc.dept_name = @dept_name and sc.class_num = @class_num
		)

go

select * from classTable('�������ѧ�뼼��', 'Z1704')

create function insTable(@ins_num varchar(20))
returns table
as return(
	select instructor.ID �̹����, instructor.i_name �̹�����, sec.course_id �γ̺�, sec.sec_id �γ̶�, 
	course.title �γ���, sec.building+sec.room_number �γ̽���, sec.sec_day+sec.start_time �Ͽ�ʱ��,
	sec.sec_year+'��'+sec.semester ѧ����Ϣ
	from 
		teaches
		join section sec
			on(sec.course_id = teaches.course_id and sec.sec_id = teaches.sec_id 
				and sec.semester = teaches.semester and sec.sec_year = teaches.sec_year) 
		join instructor 
			on(teaches.i_ID = instructor.ID)
		join course
			on(teaches.course_id = course.course_id)
	where teaches.i_ID = @ins_num

	)
go

select * from insTable('100012')




create function classGrade(@dept_name varchar(20), @class_num char(10))
returns table
as return(
	select course.title �γ���, 
		MAX(takes.grade) ��߷�, AVG(takes.grade) ƽ����, MIN(takes.grade) ��ͷ�
	from student join class on(student.dept_name = class.dept_name and student.class_num = class.class_num)
		join takes on(student.ID = takes.s_ID) join course on(takes.course_id = course.course_id)
	where class.dept_name = @dept_name and class.class_num = @class_num
	group by course.title
	)
go


select * from classGrade('�������ѧ�뼼��', 'Z1704')










create function stuGrade(@s_ID varchar(20))
returns table
as return(
	select student.ID ѧ��, student.s_name ����, student.dept_name+student.class_num �༶, course.title �γ���, takes.grade �ɼ�
		from student join takes on(student.ID = takes.s_ID) join course on(takes.course_id = course.course_id)
		where student.ID = @s_ID
	)
go


select * from stuGrade('2017000089')
