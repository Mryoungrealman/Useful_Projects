create table department
(
	dept_name varchar(20) primary key,
	building varchar(20),
	budget float
)

create table class
(
	dept_name varchar(20),
	class_num char(10),
	capacity int,
	primary key(dept_name, class_num),
	constraint FK_class foreign key(dept_name) references department(dept_name)
)

create table student
(
	ID varchar(20) primary key,
	s_name varchar(10),
	age int,
	gender char(10),
	tot_credit float,
	dept_name varchar(20),
	class_num char(10),
	constraint FK_stu foreign key(dept_name, class_num) references class(dept_name, class_num)
)

create table classroom
(
	building varchar(20),
	room_number char(10),
	capacity int,
	primary key(building, room_number)
)

create table course
(
	course_id char(10) primary key,
	title varchar(20),
	credits float,
	dept_name varchar(20)
	constraint FK_course foreign key(dept_name) references department(dept_name)
)

create table section
(
	course_id char(10),
	sec_id char(10),
	semester char(10),
	sec_year char(10),
	building varchar(20),
	room_number char(10),
	sec_day char(10),
	start_time char(10)
	primary key(course_id, sec_id, semester, sec_year)
	alter table section add constraint FK_sec1 foreign key(building, room_number) references classroom(building, room_number)
	alter table section add constraint FK_sec2 foreign key(course_id) references course(course_id)
)

create table sec_class
(
	dept_name varchar(20),
	class_num char(10),	
	course_id char(10),
	sec_id char(10),
	semester char(10),
	sec_year char(10),
	primary key(dept_name, class_num, course_id, sec_id, semester, sec_year),
	constraint FK_sec_class1 foreign key(dept_name, class_num) references class(dept_name, class_num),
	constraint FK_sec_class2 foreign key(course_id, sec_id, semester, sec_year) references section(course_id, sec_id, semester, sec_year)
)

create table takes
(
	s_ID varchar(20),
	course_id char(10),
	sec_id char(10),
	semester char(10),
	sec_year char(10), 
	grade int,
	primary key(s_ID, course_id, sec_id, semester, sec_year),
	constraint FK_takes1 foreign key(s_ID) references student(ID),
	constraint FK_takes2 foreign key(course_id, sec_id, semester, sec_year) references section(course_id, sec_id, semester, sec_year)
)

create table instructor
(
	ID varchar(20) primary key,
	i_name varchar(10),
	age int,
	gender char(10),
	salary float,
	dept_name varchar(20),
	constraint FK_ins foreign key(dept_name) references department(dept_name)
)

create table teaches
(
	i_ID varchar(20),
	course_id char(10),
	sec_id char(10),
	semester char(10),
	sec_year char(10), 
	primary key(i_ID, course_id, sec_id, semester, sec_year),
	constraint FK_teaches1 foreign key(i_ID) references instructor(ID),
	constraint FK_teaches2 foreign key(course_id, sec_id, semester, sec_year) references section(course_id, sec_id, semester, sec_year)

)


